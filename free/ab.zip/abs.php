
	
<?php
  $path = getcwd();
  echo "Your Absoluthe Path is: "; echo $path;
?>